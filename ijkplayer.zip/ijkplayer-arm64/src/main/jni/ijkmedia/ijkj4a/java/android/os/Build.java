package android.os;

public class Build {
    public static class VERSION {
        public static final int SDK_INT;
    }
}
